﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace jaggedarr
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] c = new int[3][];
            c[0] = new int[]{1,2,3,4,5};
            c[1] = new int[]{6,7,8,9,10};
            c[2] = new int[]{11,12,13,14,15};
            Console.WriteLine("Jagged Array:");
            for(int i=0;i<c.Length;i++)
            {
                for(int j=0;j<c[i].Length;j++)
                {
                    Console.Write(" "+c[i][j]);
                }
                Console.WriteLine();
            }
            Console.Read();
        }
    }
}
