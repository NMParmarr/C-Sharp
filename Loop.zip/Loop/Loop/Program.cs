﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int n,i=1,old=2,New=3;
            Console.WriteLine("Enter Any Number:");
            n = Convert.ToInt32(Console.ReadLine());
            do
            {
                if (i <= 3)
                {
                    Console.WriteLine(i + " ");
                    i++;
                }
                else
                {
                    i = old * New;
                    if (i >= n)
                    {
                        break;
                    }
                    Console.WriteLine(i + " ");
                    old = New;
                    New = i;
                }
            }while(i<=n);
            Console.Read();
        }
    }
}
